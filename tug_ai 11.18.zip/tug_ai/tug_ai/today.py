# -*- coding: utf-8 -*-
"""오늘 배정: 도선예보(DB) → ①~⑤ → 배정안 + 근거 (엑셀 저장)

  - 작업 목록: tug_agent.db의 forecast (Crawling.py가 수집). 오늘 미완료가 없으면 크롤링을 먼저 시도.
  - 당직: 당직표의 그날 행 / 건수: 건수일지 공식 건수 시트 / 이력·사례: 건수일지 + 작업일지
  - 가중치: evaluate.py가 저장한 weights.json (없으면 A 규칙만)
  - 오늘 이미 끝난 작업의 사용 예선은 도선예보에 없어서 반영하지 못한다 → 출력에 표시

실행: python today.py [--date 2026-11-17] [--mode E|C|A] [--no-crawl]
"""
import argparse
import datetime as dt
import sys

import config as C
from common import Job, t2min, to_float
from data import Dataset
from features import State, build, describe, learn_berth_port
from llm import LLM
from pipeline import decide
from rag import CaseIndex, ManualRAG
from report import write_xlsx
from scorer import Model, score_rule_as_written


def forecast_jobs(day: dt.date, crawl=True) -> list:
    import Build_db as bdb
    stamp = day.isoformat()
    if crawl and day == dt.date.today() and not bdb.has_forecast(stamp, "미완료"):
        print("[크롤링] 오늘 도선예보 수집 중…", file=sys.stderr)
        from Crawling import main as crawl_main
        crawl_main()
    kind, crawled_at, recs = bdb.load_forecast(stamp)
    if kind is None:
        raise LookupError(f"DB에 {stamp} 도선예보가 없습니다. Crawling.py를 먼저 실행하세요.")
    print(f"[도선예보] {stamp} '{kind}' {len(recs)}건 (수집 {crawled_at})")
    jobs = []
    for n, r in enumerate(recs, 1):
        t = t2min(r.get("TIME"))
        if t is None:
            continue
        frm, to = str(r.get("FROM") or "").strip(), str(r.get("TO") or "").strip()
        kind_ = "M" if frm.upper().startswith("P/S") else "U" if to.upper().startswith("P/S") else "S"
        jobs.append(Job(date=day, time=t, ship=str(r.get("SHIP'S NAME") or "").strip(), gt=to_float(r.get("G/T")),
                        frm=frm, to=to, kind=kind_, need_k=int(to_float(r.get("T")) or 0),
                        note=str(r.get("REMARKS") or ""), seq=n))
    return sorted(jobs, key=lambda j: (j.stamp, j.seq))


def main(argv=None, llm=None, jobs=None):
    p = argparse.ArgumentParser(description="오늘 예선 배정안")
    p.add_argument("--date", default=dt.date.today().isoformat())
    p.add_argument("--mode", default="E", choices=list("ABCDE"))
    p.add_argument("--data", default=str(C.DATA_DIR))
    p.add_argument("--no-crawl", action="store_true")
    a = p.parse_args(argv)
    day = dt.date.fromisoformat(a.date)

    ds = Dataset(a.data, need_logs="auto")
    jobs = jobs if jobs is not None else forecast_jobs(day, crawl=not a.no_crawl)
    warns = []
    if day not in ds.plan and day not in ds.heads:
        warns.append(f"당직표에 {day} 행이 없음 → 당직선/같은 항 항목이 비어 있음")
    if ds.asof and (day - ds.asof).days > 1:
        warns.append(f"공식 건수 기준일 {ds.asof} → {(day - ds.asof).days}일 지난 건수로 처진순 계산")
    warns.append("오늘 이미 끝난 작업의 사용 예선은 반영되지 않음(작업 중·건수 판단이 실제와 다를 수 있음)")

    mode = a.mode
    scorers = {"A": score_rule_as_written}
    if C.WEIGHTS.exists():
        scorers["B"] = scorers["C"] = Model.load(C.WEIGHTS)
    elif mode != "A":
        warns.append("weights.json 없음 → evaluate.py를 먼저 실행하세요. 이번에는 A(규칙 그대로)로 배정")
        mode = "A"
    llm = llm or (LLM() if mode in "DE" else None)
    if mode in "DE" and not llm.enabled:
        warns.append("LLM(ollama) 없음 → C(점수 모델) 결과로 배정")

    st = State(ds, ds.official, cases=CaseIndex())
    for j in ds.history + ds.logs:
        if j.actual and j.stamp < day.toordinal() * 1440 and all(n in ds.grp for n in j.actual):
            for n in j.actual:
                st.ship_hist[j.ship][n] += 1
            st.cases.add(j, j.actual)
    berth_port = learn_berth_port(ds, ds.logs, day) if ds.logs else {}
    manual = ManualRAG()

    print(f"[배정] {day} 방식 {mode}" + "".join(f"\n  ⚠ {w}" for w in warns))
    rows = [["시각", "선박", "G/T", "구분", "부두", "척수", "배정", "상태", "이유", "자리1 후보(점수)", "근거(과거 사례)", "비고"]]
    for j in jobs:
        ctx = build(j, st, berth_port)
        if ctx is None:
            print(f"{j.time // 60:02d}:{j.time % 60:02d} {j.ship:<20s} → [미배정] 톤수 또는 척수 정보 없음")
            rows.append([f"{j.time // 60:02d}:{j.time % 60:02d}", j.ship, j.gt, j.kind, j.berth, j.need_k,
                         "", "미배정", "톤수/척수 없음", "", "", j.note])
            continue
        ctx.cases = st.cases.search(j)
        d = decide(ctx, mode, scorers, llm=llm, manual=manual)
        cand = ", ".join(f"{n}({s:+.1f})" for n, s in (d.ranks[0] if d.ranks else [])[:C.TOP_M])
        print(f"{j.time // 60:02d}:{j.time % 60:02d} {j.ship[:20]:<20s} {j.kind} {j.berth:<8s} "
              f"G/T {int(j.gt):>6,} {len(ctx.need)}척 → {', '.join(d.picked) or '[후보 없음]'}  [{d.status}]")
        for n in d.picked:
            print(f"        └ {n}: {describe(ctx, n)}")
        if d.reason:
            print(f"        └ 이유: {d.reason}")
        rows.append([f"{j.time // 60:02d}:{j.time % 60:02d}", j.ship, int(j.gt), j.kind, j.berth, len(ctx.need),
                     ", ".join(d.picked), d.status, d.reason, cand,
                     " / ".join(d.evidence.get("cases", [])[:3]), j.note])
        st.apply(j, d.picked)          # 다음 작업은 이 배정을 반영한 상태에서 고른다
    out = write_xlsx(C.OUT_DIR / f"오늘배정_{day}.xlsx", {"배정안": rows, "주의": [["주의"]] + [[w] for w in warns]})
    print(f"\n저장: {out}\n※ 배정안은 검토용입니다. 최종 배정은 담당자가 확인합니다.")


if __name__ == "__main__":
    main()
