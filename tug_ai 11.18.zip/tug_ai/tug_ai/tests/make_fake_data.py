# -*- coding: utf-8 -*-
"""테스트용 가짜 엑셀 3종 (실제 파일 구조를 흉내냄). 실제 데이터 아님.
실행: python tests/make_fake_data.py   -> tests/fake_data/ 에 당직표·건수일지·작업일지 생성"""
import datetime as dt
import random
import sys
from collections import Counter
from pathlib import Path

from openpyxl import Workbook

PKG = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PKG))
from common import allowed_tier, norm  # noqa

random.seed(7)
OUT = Path(sys.argv[1]) if len(sys.argv) > 1 else PKG / "tests" / "fake_data"
OUT.mkdir(parents=True, exist_ok=True)
G = {1300: ["조광101", "109청룡", "선진8", "조107", "해강9", "해101"],
     1500: ["K101", "조105", "선9", "흥진5", "조3", "111청룡", "선진6", "흥진7"],
     2000: ["쥬피터", "선7", "조12", "선2", "팔도", "선802", "강산", "선803", "조201", "선101"],
     3000: ["바다2", "K601", "해7", "선808", "해15", "처용", "SBM9", "에코미르", "선909", "조11", "바다1", "제우스",
            "선606", "선202", "조13", "선900", "조601", "SBM11", "505해룡", "울산", "선11", "해11", "선111", "흥3"]}
K3 = {"해7", "처용", "선909", "제우스", "조13", "SBM11", "선11", "흥3"}
grp = {norm(n): g for g, ns in G.items() for n in ns}
tier = {n: (g if g < 3000 or n in K3 else 4000) for n, g in grp.items()}
BON = ["P#3", "GP#2", "HCP#1", "YMP#1", "P#6"]
ONS = ["SK#5-4", "UTT", "OP#3", "SOILF1", "JSTT4", "LPG#2", "UTK#2", "SP#6"]
SHIPS = [(f"SHIP {i:03d}", random.choice([2500, 4000, 6000, 8500, 12000, 20000, 27000, 35000, 60000])) for i in range(150)]


def rot(lst, k, n):
    return [lst[(k + i) % len(lst)] for i in range(n)]


def duty_for(d: dt.date):
    k = d.toordinal()
    on13, on15, on20 = rot(G[1300], k, 2), rot(G[1500], k, 2), rot(G[2000], k, 2)
    t3 = rot(G[3000], k * 3, 3)
    bn13, bn15, bn20 = rot(G[1300], k + 3, 2), rot(G[1500], k + 4, 2), rot(G[2000], k + 5, 2)
    return on13 + on15 + on20 + t3[:1], t3[1:2], t3[2:3] + bn13 + bn15 + bn20   # 열 3..9 / 10 / 11..17


# ── 당직표
wb = Workbook(); wb.remove(wb.active)
for y, m, nd in ((2026, 6, 30), (2026, 7, 31)):
    ws = wb.create_sheet(f"{y}년 {m}월")
    ws.append(["TUG 당직표"]); ws.append(["날짜", "", "", "온산"]); ws.append(["", "", "", "1,300HP"])
    for d in range(1, nd + 1):
        on, cr, bn = duty_for(dt.date(y, m, d))
        ws.append([f"{m}/{d}", "", ""] + on + cr + bn + ["", "비고"])
wb.save(OUT / "TUG 당직표.xlsx")

# ── 작업 시뮬레이션 (가상의 배정 담당자)
count = Counter({n: random.randint(80, 120) for n in grp})
busy, ship_hist = {}, {}


def simulate(day, n_jobs, with_log):
    on, cr, bn = duty_for(day if True else day)
    jobs = []
    for _ in range(n_jobs):
        t = random.randint(0, 1439)
        ship, gt = random.choice(SHIPS)
        kind = random.choice("MU")
        port = random.choice(["bon", "onsan"])
        berth = random.choice(BON if port == "bon" else ONS)
        k = 1 if gt < 5000 and random.random() < .4 else 2
        note = "5,000HP 이상 요청" if gt >= 50000 and random.random() < .3 else ""
        jobs.append([t, ship, gt, kind, berth, port, k, note])
    jobs.sort()
    out = []
    for t, ship, gt, kind, berth, port, k, note in jobs:
        now = day.toordinal() * 1440 + t
        dday = day - dt.timedelta(days=1) if t < 360 else day
        on, cr, bn = duty_for(dday)
        duty = {norm(x) for x in on + cr + bn}
        same = {norm(x) for x in (bn if port == "bon" else on) + cr}
        picked = []
        for need in allowed_tier(gt, k):
            if note:
                need = {4000}
            cands = [n for n in grp if tier[n] in need and n not in picked and busy.get(n, 0) <= now]
            if not cands:
                cands = [n for n in grp if tier[n] >= min(need) and n not in picked]
            weekday_am = day.weekday() < 5 and 360 <= t < 720

            def s(n):
                v = random.random() * 0.8
                v += 2.5 * (n in same) + 1.0 * (n in duty)
                v += (-0.05 if weekday_am else -0.01) * count[n]
                v += 1.5 * (ship_hist.get((ship, n), 0) > 0)
                return v
            pick = max(cands, key=s)
            picked.append(pick)
        dur = 60 if kind == "M" else 30
        for n in picked:
            count[n] += 1; busy[n] = now + dur
            ship_hist[(ship, n)] = ship_hist.get((ship, n), 0) + 1
        frm, to = ("P/S", berth) if kind == "M" else (berth, "P/S")
        raw = lambda n: next(x for g in G.values() for x in g if norm(x) == n)
        out.append(dict(t=t, ship=ship, gt=gt, frm=frm, to=to, kind=kind, tugs=",".join(raw(n) for n in picked),
                        k=len(picked), note=note))
    return out


hist_days = [dt.date(2026, 6, d) for d in range(1, 31)]
log_days = [dt.date(2026, 7, d) for d in range(1, 28)]
hist = {d: simulate(d, 35, False) for d in hist_days}
logs = {d: simulate(d, 35, True) for d in log_days}

# ── 건수일지: 'YYYY년 작업(6)' (날짜 블록이 옆으로 반복) + 전체 건수 시트
wb = Workbook(); wb.remove(wb.active)
for chunk in range(0, 30, 10):
    ws = wb.create_sheet(f"2026년 작업({6 * 10 + chunk // 10})")
    days = hist_days[chunk:chunk + 10] + (log_days[chunk:chunk + 10] if chunk == 0 else [])
    grid = {}
    for b, d in enumerate(days):
        c = b * 10
        grid[(0, c)] = "날짜"; grid[(0, c + 1)] = dt.datetime(d.year, d.month, d.day)
        for h, v in enumerate(["시간", "선명", "", "G/T", "FROM", "TO", "", "구분", "사용예선"]):
            grid[(1, c + h)] = v
        for r, j in enumerate((hist.get(d) or logs[d]), 2):
            for h, v in enumerate([f"{j['t'] // 60:02d}:{j['t'] % 60:02d}", j["ship"], "", j["gt"], j["frm"], j["to"],
                                   "", j["kind"], j["tugs"]]):
                grid[(r, c + h)] = v
    R = max(r for r, _ in grid) + 1; Ccol = max(c for _, c in grid) + 1
    for r in range(R):
        ws.append([grid.get((r, c)) for c in range(Ccol)])
ws = wb.create_sheet("★전체 건수★(2026)")
ws.append(["전체 건수"]); ws.append([]); ws.append(["기준일", dt.datetime(2026, 7, 27)]); ws.append([]);
names = [x for g in G.values() for x in g]
for i in range(12):
    row = [None] * 20
    for b, c in enumerate((5, 9, 13, 17)):
        n = names[i * 4 + b]
        row[c] = n; row[c + 1] = count[norm(n)]
    ws.append(row)
wb.save(OUT / "건수일지.xlsx")

# ── 작업일지: '26년 7월일지(d)'
wb = Workbook(); wb.remove(wb.active)
for d in log_days:
    ws = wb.create_sheet(f"26년 7월일지({d.day})")
    on, cr, bn = duty_for(d)
    ws.append(["본항당직", ",".join(bn)]); ws.append(["교차당직", ",".join(cr)]); ws.append(["온산당직", ",".join(on)])
    ws.append(["조기퇴근", "(16:00)" + random.choice(G[1500])]); ws.append(["수리선", random.choice(G[2000])])
    ws.append(["예정시간", "선명", "", "G/T", "FROM", "TO", "CA", "구분", "사용예선", "L/A", "T", "비고"])
    for j in logs[d]:
        ws.append([f"{j['t'] // 60:02d}:{j['t'] % 60:02d}", j["ship"], "", j["gt"], j["frm"], j["to"], "", j["kind"],
                   j["tugs"], "", j["k"], j["note"]])
wb.save(OUT / "작업일지.xlsx")
print("가짜 데이터:", OUT, "/ 과거", sum(map(len, hist.values())), "건, 7월", sum(map(len, logs.values())), "건")
