# -*- coding: utf-8 -*-
"""전체 흐름 점검 (실제 데이터·Ollama 없이): 가짜 데이터 + 가짜 LLM으로 A~E 평가를 돌린다.
실행: python tests/smoke_test.py
"""
import json
import re
import subprocess
import sys
from pathlib import Path

PKG = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PKG))
import config as C  # noqa: E402

FAKE = PKG / "tests" / "fake_data"
if not (FAKE / C.F_LOG).exists():
    subprocess.run([sys.executable, str(PKG / "tests" / "make_fake_data.py"), str(FAKE)], check=True)


class FakeLLM:
    """1위를 고르되, '이 선박을 가장 많이 맡은 예선'이 후보에 있으면 그쪽을 고르는 가짜 모델"""
    def chat(self, model, think, format, options, messages):
        user = messages[1]["content"]
        m = re.search(r"가장 많이 맡은 예선: (.+)", user)
        fav = [x.strip() for x in m.group(1).split(",")] if m else []
        ans, used = {}, set()
        for k, v in format["properties"].items():
            if k.startswith("slot"):
                pick = next((f for f in fav if f in v["enum"] and f not in used), v["enum"][0])
                ans[k] = pick
                used.add(pick)
        ans["reason"] = "이 선박 담당 이력" if fav else "점수 1위 유지"
        return {"message": {"content": json.dumps(ans, ensure_ascii=False)}}


if __name__ == "__main__":
    from llm import LLM
    import evaluate
    C.WEIGHTS = PKG / "tests" / "weights_test.json"
    evaluate.main(["--data", str(FAKE), "--llm-limit", "60", "--no-manual"], llm=LLM(client=FakeLLM(), cache_path=None))
    print("\n[점검 통과] 숫자는 가짜 데이터 결과라 의미 없음")
