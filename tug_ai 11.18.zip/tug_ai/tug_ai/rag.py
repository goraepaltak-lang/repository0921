# -*- coding: utf-8 -*-
"""③ RAG 근거 검색. 두 가지 근거를 찾는다.

  1) 과거 배정 사례 (CaseIndex): 같은 선박 / 같은 부두·작업종류 사례를 각각 최신순으로 찾고
     RRF(Reciprocal Rank Fusion)로 합친다. -> "이 배·이 부두에서 그동안 누가 나갔나"
     ※ 작업 시각 이전 기록만 들어 있다(시간순으로 add 하므로 미래 정보가 섞이지 않음).
  2) 매뉴얼 조항 (ManualRAG): Build_vectors.py가 만든 FAISS 인덱스를 embeddinggemma로 검색.
     faiss/ollama/인덱스가 없으면 자동으로 꺼진다.
"""
import json
import re
import sys
from collections import Counter, defaultdict

import config as C
from common import Job


def _key(s: str) -> str:
    return re.sub(r"\s+", "", str(s or "")).upper()


class CaseIndex:
    def __init__(self):
        self.rows = []                          # (stamp, job, names)
        self.by_ship = defaultdict(list)        # 선박 -> 행 번호
        self.by_berth = defaultdict(list)       # (부두, 작업종류) -> 행 번호

    def add(self, job: Job, names: list):
        if not names:
            return
        i = len(self.rows)
        self.rows.append((job.stamp, job, list(names)))
        self.by_ship[_key(job.ship)].append(i)
        self.by_berth[(_key(job.berth), job.kind)].append(i)

    def search(self, job: Job, k: int = C.CASES_K, rrf_k: int = 60) -> list:
        """RRF로 합친 상위 k개 사례 [(job, names, 근거종류)]"""
        lists = {"같은 선박": self.by_ship.get(_key(job.ship), [])[-20:][::-1],
                 "같은 부두": self.by_berth.get((_key(job.berth), job.kind), [])[-20:][::-1]}
        score, why = Counter(), defaultdict(list)
        for label, ids in lists.items():
            for rank, i in enumerate(ids):
                if self.rows[i][0] < job.stamp:
                    score[i] += 1 / (rrf_k + rank + 1)
                    why[i].append(label)
        return [(self.rows[i][1], self.rows[i][2], "+".join(why[i])) for i, _ in score.most_common(k)]


class ManualRAG:
    def __init__(self, enabled=True):
        self.enabled = enabled and C.MANUAL_INDEX.exists() and C.MANUAL_CHUNKS.exists()
        self._index = self._chunks = None
        self._cache = {}

    def search(self, query: str, k: int = 2, max_chars: int = 260) -> list:
        if not self.enabled:
            return []
        if query in self._cache:
            return self._cache[query]
        try:
            import faiss
            import numpy as np
            from ollama import embed
            if self._index is None:
                self._index = faiss.read_index(str(C.MANUAL_INDEX))
                self._chunks = json.loads(C.MANUAL_CHUNKS.read_text(encoding="utf-8"))
            v = np.array(embed(model=C.EMBED_MODEL, input=[query]).embeddings, dtype=np.float32)
            faiss.normalize_L2(v)
            D, I = self._index.search(v, k)
            out = [" ".join(self._chunks[i].split())[:max_chars] for i in I[0] if i >= 0]
        except Exception as e:                      # 라이브러리/Ollama 없음 -> 매뉴얼 근거만 끈다
            print(f"[매뉴얼 RAG 끔] {type(e).__name__}: {e}", file=sys.stderr)
            self.enabled = False
            return []
        self._cache[query] = out
        return out


def manual_query(slot: str, tier: int, job: Job) -> str:
    """작업 상황 -> 매뉴얼 검색 문장 (같은 상황은 같은 문장이 되어 캐시가 잘 맞는다)"""
    hp = {1300: "1,000HP", 1500: "1,000HP", 2000: "2,000HP", 3000: "3,000HP", 4000: "3,000HP"}.get(tier, "")
    when = {"평일 오전": "평일 오전 처진순", "평일 오후": "평일 오후 당직순번", "주말 주간": "주말 당직순번",
            "야간": "야간 당직선 번갈아"}[slot]
    return f"{hp}급 선박 배정순서 {when} 배정"
