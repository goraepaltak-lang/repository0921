# -*- coding: utf-8 -*-
"""평가: 과거 작업일지를 시간순으로 다시 돌려 A~E를 실제 배정과 비교한다 (팀 공식 점수판).

  - 한 건씩 끊어서 비교: 매 작업마다 '실제로 일어난 상태'(건수·작업 중·이력)를 넣고 그 한 건만 고르게 한 뒤,
    다음 작업 전에는 실제 배정을 반영한다. 그래서 오차가 다음 건으로 번지지 않는다.
  - 학습 기간(가중치 맞추기)과 확인 기간(성적 측정)을 날짜로 나눈다.
  - LLM 모드(D/E)는 시간이 걸려서 확인 기간 앞쪽 N건(--llm-limit)만 돌리고, 같은 건으로 A~C도 다시 잰다.

실행: python evaluate.py [--data 폴더] [--train-until 2026-07-20] [--llm-limit 150] [--no-llm]
"""
import argparse
import datetime as dt
import sys
from collections import Counter, defaultdict

import config as C
from common import allowed
from data import Dataset
from features import FEATURES, State, build, learn_berth_port
from llm import LLM
from pipeline import decide
from rag import CaseIndex, ManualRAG
from report import write_xlsx
from scorer import MODELS_B_FEATURES, MODELS_C_FEATURES, fit, score_rule_as_written

MODE_NAME = {"A": "A. 규칙 그대로", "B": "B. 규칙+가중치", "C": "C. 규칙+경험 점수",
             "D": "D. C+LLM (RAG 없음)", "E": "E. C+RAG+LLM (최종)"}
SLOTS = ("평일 오전", "평일 오후", "주말 주간", "야간")


# ───────────────────────────── 0) 톤수표 검증 (마력급)
def hp_check(ds) -> list:
    rows, res = [], Counter()
    bands = [(0, 5000, "5천 톤 미만"), (5000, 7000, "5천~7천"), (7000, 10000, "7천~1만"),
             (10000, 25000, "1만~2만5천"), (25000, 30000, "2만5천~3만"), (30000, 10 ** 9, "3만 이상")]
    by = defaultdict(Counter)
    for j in ds.history:
        if j.date < C.RULE_START or j.kind not in ("M", "U") or j.gt is None or not j.actual:
            continue
        if not all(n in ds.grp for n in j.actual):
            continue
        groups = sorted((ds.grp[n] for n in j.actual), reverse=True)
        up = down = False
        for a, s in zip(groups, allowed(j.gt, len(groups))):
            if a in s:
                continue
            up, down = (True, down) if a > max(s) else (up, True)
        r = "일치" if not (up or down) else "상위" if up and not down else "하위" if down and not up else "혼합"
        b = next(name for lo, hi, name in bands if lo <= j.gt < hi)
        by[b][r] += 1
        res[r] += 1
    total = sum(res.values())
    rows.append(["총톤수 구간", "건수", "일치", "상위 마력", "하위 마력", "일치율"])
    for _, _, b in bands:
        c = by[b]; n = sum(c.values())
        rows.append([b, n, c["일치"], c["상위"], c["하위"], f"{c['일치'] / n:.1%}" if n else "-"])
    rows.append(["전체", total, res["일치"], res["상위"], res["하위"], f"{res['일치'] / total:.1%}" if total else "-"])
    return rows


# ───────────────────────────── 1) 작업 재생 -> 작업별 후보 특징
def replay(ds, train_until: dt.date):
    logs = ds.logs
    if not logs:
        raise ValueError("작업일지에서 읽은 작업이 없습니다. config.F_LOG와 시트 이름('26년 7월일지(1)')을 확인하세요.")
    first = logs[0].date
    known = set(ds.tugs)
    # 건수: 공식 건수(기준일)에서 작업일지 기간의 작업 수를 빼 시작값을 만든다
    counts = Counter(ds.official)
    for j in logs:
        if j.actual and (ds.asof is None or j.date <= ds.asof):
            for n in j.actual:
                counts[n] -= 1
    st = State(ds, counts, cases=CaseIndex())
    for j in ds.history:                      # 작업일지 이전 기록 = 선박 이력 + RAG 사례
        if j.date < first and j.actual and all(n in ds.grp for n in j.actual):
            for n in j.actual:
                st.ship_hist[j.ship][n] += 1
            st.cases.add(j, j.actual)
    berth_port = learn_berth_port(ds, logs, train_until)
    ctxs, stat = [], Counter()
    for j in logs:
        if j.actual and j.gt is not None and j.kind in ("M", "U") and all(n in known for n in j.actual):
            ctx = build(j, st, berth_port)
            if ctx:
                ctx.cases = st.cases.search(j)       # 이 시점까지의 기록만 검색됨
                ctxs.append(ctx)
                dd = ds.dayinfo(j.duty_date)
                duty = set(dd["bon"]) | set(dd["onsan"]) | set(dd["cross"])
                stat["실제 예선"] += len(j.actual)
                stat["그중 당직선"] += sum(n in duty for n in j.actual)
        if j.actual:
            st.apply(j, j.actual)
    return ctxs, berth_port, stat


# ───────────────────────────── 2) 채점
def score(items) -> dict:
    """items: [(ctx, Decision)]"""
    out = Counter()
    for ctx, d in items:
        actual = set(ctx.job.actual)
        k = len(actual)
        out["건"] += 1
        out["건 완전 일치"] += set(d.picked) == actual
        out["예선"] += k
        out["예선 일치"] += len(set(d.picked) & actual)
        top = {n for n, _ in (d.ranks[0] if d.ranks else [])[:k + 2]}
        out["상위 후보 안"] += sum(a in top for a in actual)
    return out


def fmt(o):
    return (f"건 {o['건 완전 일치'] / max(1, o['건']):.1%} | 예선 {o['예선 일치'] / max(1, o['예선']):.1%}")


def llm_effect(base_items, llm_items) -> dict:
    """LLM이 C의 선택을 바꾼 효과: 바꾼 건수, 바꿔서 맞힌 예선 수 - 바꿔서 틀린 예선 수"""
    o = Counter()
    for (ctx, c), (_, e) in zip(base_items, llm_items):
        actual = set(ctx.job.actual)
        o["상태:" + e.status.split(":")[0]] += 1
        if set(e.picked) != set(c.picked):
            o["바꾼 건"] += 1
            o["바꿔서 맞힌 예선"] += len((set(e.picked) - set(c.picked)) & actual)
            o["바꿔서 틀린 예선"] += len((set(c.picked) - set(e.picked)) & actual)
    return o


# ───────────────────────────── 실행
def main(argv=None, llm=None):
    p = argparse.ArgumentParser(description="A~E 배정 방식 비교 평가")
    p.add_argument("--data", default=str(C.DATA_DIR))
    p.add_argument("--train-until", help="가중치를 맞출 마지막 날 YYYY-MM-DD (기본: 앞쪽 70%% 날짜)")
    p.add_argument("--llm-limit", type=int, default=150, help="LLM으로 돌릴 확인 기간 작업 수 (0=전부)")
    p.add_argument("--no-llm", action="store_true")
    p.add_argument("--no-manual", action="store_true", help="매뉴얼 RAG 끄기 (과거 사례 RAG만)")
    a = p.parse_args(argv)

    ds = Dataset(a.data, need_logs=True)
    days = sorted({j.date for j in ds.logs})
    train_until = (dt.date.fromisoformat(a.train_until) if a.train_until
                   else days[max(0, int(len(days) * 0.7) - 1)])
    print(f"예선 {len(ds.tugs)}척 / 과거 기록 {len(ds.history):,}건 / 작업일지 {len(ds.logs):,}건 "
          f"({days[0]}~{days[-1]}) / 학습 ~{train_until}")

    hp_rows = hp_check(ds)
    print(f"[톤수표 검증] 마력급 일치율 {hp_rows[-1][-1]} ({hp_rows[-1][1]:,}건)")

    ctxs, berth_port, stat = replay(ds, train_until)
    train = [c for c in ctxs if c.job.date <= train_until]
    test = [c for c in ctxs if c.job.date > train_until]
    if not train or not test:
        sys.exit("[오류] 학습/확인 기간 중 한쪽에 작업이 없습니다. --train-until을 조정하세요.")
    print(f"[재생] 비교 대상 {len(ctxs):,}건 = 학습 {len(train):,} + 확인 {len(test):,}, "
          f"실제 예선 중 당직선 {stat['그중 당직선'] / max(1, stat['실제 예선']):.1%}, 항 추정 부두 {len(berth_port)}곳")

    scorers = {"A": score_rule_as_written,
               "B": fit(train, MODELS_B_FEATURES, name="B"),
               "C": fit(train, MODELS_C_FEATURES, name="C")}
    results = {m: [(c, decide(c, m, scorers)) for c in test] for m in "ABC"}

    use_llm = not a.no_llm
    llm = llm or (LLM() if use_llm else None)
    if use_llm and not llm.enabled:
        print("[LLM 없음] ollama를 설치·실행하면 D/E도 평가합니다. (pip install ollama, ollama pull " + C.LLM_MODEL + ")")
        use_llm = False
    sub = test if a.llm_limit <= 0 else test[:a.llm_limit]
    if use_llm:
        manual = ManualRAG(enabled=not a.no_manual)
        print(f"[LLM] {C.LLM_MODEL}로 확인 기간 {len(sub)}건 × D/E 실행 중 (캐시 사용)…", flush=True)
        for m in "DE":
            out = []
            for i, c in enumerate(sub, 1):
                out.append((c, decide(c, m, scorers, llm=llm, manual=manual)))
                if i % 25 == 0:
                    print(f"   {m} {i}/{len(sub)}", flush=True)
            results[m] = out
        results_sub = {m: results[m][:len(sub)] for m in "ABC"}
        results_sub.update({m: results[m] for m in "DE"})

    # ── 출력
    summary = [["구간", "방식", "건수", "건 완전 일치율", "예선 일치율", "상위 후보(척수+2) 포함률"]]

    def add(label, res):
        for m, items in res.items():
            o = score(items)
            summary.append([label, MODE_NAME[m], o["건"], f"{o['건 완전 일치'] / o['건']:.1%}",
                            f"{o['예선 일치'] / o['예선']:.1%}", f"{o['상위 후보 안'] / o['예선']:.1%}"])
            print(f"   {MODE_NAME[m]:<18s} {fmt(o)}")
    print(f"\n[확인 기간 전체 {len(test)}건]")
    add("확인 기간 전체", {m: results[m] for m in "ABC"})
    if use_llm:
        print(f"\n[LLM 비교 구간 {len(sub)}건] (같은 작업으로 A~E 비교)")
        add(f"LLM 비교 {len(sub)}건", results_sub)

    by_slot = [["시간대", "건수"] + [MODE_NAME[m] for m in (results_sub if use_llm else results)]]
    base = results_sub if use_llm else results
    for s in SLOTS:
        row = [s, sum(1 for c, _ in base["A"] if c.slot == s)]
        for m, items in base.items():
            o = score([(c, d) for c, d in items if c.slot == s])
            row.append(f"{o['예선 일치'] / max(1, o['예선']):.1%}")
        by_slot.append(row)

    effect_rows = [["방식", "항목", "값"]]
    if use_llm:
        for m in "DE":
            eff = llm_effect(results_sub["C"], results_sub[m])
            print(f"   {MODE_NAME[m]}: " + ", ".join(f"{k} {v}" for k, v in sorted(eff.items())))
            effect_rows += [[MODE_NAME[m], k, v] for k, v in sorted(eff.items())]
        effect_rows.append(["LLM", "호출 / 캐시 / 오류 / 소요(초)",
                            f"{llm.calls} / {llm.hits} / {llm.errors} / {llm.seconds:.0f}"])

    detail = [["날짜", "시각", "시간대", "선박", "G/T", "구분", "부두", "실제"] + [f"{m} 배정" for m in base] +
              (["E 상태", "E 이유", "E 근거(사례)"] if use_llm else [])]
    for i, (c, _) in enumerate(base["A"]):
        j = c.job
        row = [str(j.date), f"{j.time // 60:02d}:{j.time % 60:02d}", c.slot, j.ship, int(j.gt), j.kind, j.berth,
               ", ".join(j.actual)] + [", ".join(base[m][i][1].picked) for m in base]
        if use_llm:
            e = base["E"][i][1]
            row += [e.status, e.reason, " / ".join(e.evidence.get("cases", [])[:2])]
        detail.append(row)

    weights = [["항목", "구분", "B 가중치", "C 가중치"]] + [
        [f, "규칙" if f in MODELS_B_FEATURES else "경험", round(scorers["B"].w[f], 2), round(scorers["C"].w[f], 2)]
        for f in FEATURES]

    final = fit(ctxs, MODELS_C_FEATURES, name="C")     # 오늘 배정용: 전체 기간으로 다시 맞춘 C
    final.save(C.WEIGHTS, meta={"기간": f"{days[0]}~{days[-1]}", "작업 수": len(ctxs)})
    out = write_xlsx(C.OUT_DIR / f"평가결과_{dt.datetime.now():%Y%m%d_%H%M}.xlsx",
                     {"요약": summary, "시간대별": by_slot, "LLM 효과": effect_rows, "건별 비교": detail,
                      "가중치": weights, "톤수표 검증": hp_rows})
    print(f"\n보고서: {out}\n오늘 배정용 가중치 저장: {C.WEIGHTS.name}")
    return results


if __name__ == "__main__":
    main()
