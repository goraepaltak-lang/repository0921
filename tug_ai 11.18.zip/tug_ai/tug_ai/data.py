# -*- coding: utf-8 -*-
"""원본 엑셀 읽기 (팀원 '평가지표_근거계산.py'의 로더를 일반화).

  당직표  -> 예선별 마력군(grp), 날짜별 당직 계획(plan)
  건수일지 -> 과거 작업 기록(history), 공식 건수(official)
  작업일지 -> 작업 + 실제 사용 예선(logs), 날짜별 머리글(당직/조기퇴근/수리선)
"""
import datetime as dt
import re
from collections import Counter, defaultdict
from pathlib import Path

from openpyxl import load_workbook

import config as C
from common import Job, norm, split_names, t2min, to_float

EMPTY_DAY = dict(bon=[], onsan=[], cross=[], left=[], repair=[])


def _as_date(v, year=None):
    if isinstance(v, dt.datetime):
        return v.date()
    if isinstance(v, dt.date):
        return v
    m = re.fullmatch(r"\s*(\d{1,2})/(\d{1,2})\s*", str(v or ""))
    if m and year:
        try:
            return dt.date(year, int(m.group(1)), int(m.group(2)))
        except ValueError:
            return None
    return None


def load_duty(path: Path):
    """당직표 -> (grp: 예선->마력군, plan: 날짜->당직 정보)"""
    wb = load_workbook(path, read_only=True, data_only=True)
    votes, plan = defaultdict(Counter), {}
    for ws in wb.worksheets:
        m = re.search(r"(20\d{2})년\s*(\d{1,2})월", ws.title)
        year = int(m.group(1)) if m else None
        for i, row in enumerate(ws.iter_rows(values_only=True)):
            if i < 3 or not row or row[0] in (None, ""):
                continue
            r = [("" if v is None else norm(v)) for v in list(row[:20]) + [None] * (20 - len(row[:20]))]
            for c, g in C.DUTY_COLS.items():
                if r[c]:
                    votes[r[c]][g] += 1
            d = _as_date(row[0], year)
            if d:
                plan[d] = dict(onsan=[r[c] for c in C.DUTY_ONSAN if r[c]], cross=[r[c] for c in C.DUTY_CROSS if r[c]],
                               bon=[r[c] for c in C.DUTY_BON if r[c]], left=[], repair=[])
    wb.close()
    grp = {k: v.most_common(1)[0][0] for k, v in votes.items()}
    grp.update({"선808": 3000, "바다1": 3000})      # 2025년 건수일지에만 나오는 3,000마력군 이름
    return grp, plan


def load_history(path: Path) -> list:
    """건수일지 'YYYY년 작업(n)' 시트 -> Job 목록 (날짜 블록이 좌우로 반복되는 구조)"""
    wb = load_workbook(path, read_only=True, data_only=True)
    jobs = []
    for name in wb.sheetnames:
        if not re.match(r"\d{4}년 작업\(\d+\)", name):
            continue
        rows = list(wb[name].iter_rows(values_only=True))
        if len(rows) < 3:
            continue
        r0 = rows[0]
        for c in [c for c, v in enumerate(r0) if str(v or "").strip() == "날짜"]:
            d = _as_date(r0[c + 1] if c + 1 < len(r0) else None)
            if not d:
                continue
            for r in rows[2:]:
                cell = lambda k: (r[c + k] if c + k < len(r) and r[c + k] is not None else "")
                if not str(cell(1)).strip() and not str(cell(8)).strip():
                    continue
                t = t2min(cell(0))
                names = split_names(cell(8))
                jobs.append(Job(date=d, time=t if t is not None else 0, ship=str(cell(1)).strip(), gt=to_float(cell(3)),
                                frm=str(cell(4)).strip(), to=str(cell(5)).strip(), kind=str(cell(7)).strip().upper(),
                                need_k=len(names), actual=names or None))
    wb.close()
    jobs.sort(key=lambda j: j.stamp)
    return jobs


def load_official_counts(path: Path, sheet="★전체 건수★(2026)"):
    """건수일지 전체 건수 시트 -> ({예선: 건수}, 기준일)"""
    wb = load_workbook(path, read_only=True, data_only=True)
    rows = list(wb[sheet].iter_rows(values_only=True))
    wb.close()
    out = {}
    for r in rows[4:40]:
        for c in (5, 9, 13, 17):
            if c + 1 < len(r) and r[c] not in (None, "") and isinstance(r[c + 1], (int, float)):
                out[norm(r[c])] = int(r[c + 1])
    return out, _as_date(rows[2][1])


def load_logs(path: Path, known: set):
    """작업일지 'YY년 M월일지(d)' 시트 -> (Job 목록, {날짜: 머리글 정보})"""
    wb = load_workbook(path, read_only=True, data_only=True)
    keys = ("본항당직", "교차당직", "온산당직", "조기퇴근", "T/L", "수리선")
    jobs, heads = [], {}
    for sheet in wb.sheetnames:
        m = re.fullmatch(r"(\d{2})년\s*(\d{1,2})월일지\((\d{1,2})\)", sheet.strip())
        if not m:
            continue
        day = dt.date(2000 + int(m.group(1)), int(m.group(2)), int(m.group(3)))
        head, started, n = {}, False, 0
        for row in wb[sheet].iter_rows(values_only=True):
            cells = [("" if v is None else v) for v in row] + [""] * 12
            txt = [str(c).strip() for c in cells]
            if not started:
                for k in keys:
                    if k in txt:
                        nxt = [t for t in txt[txt.index(k) + 1:] if t]
                        head[k] = nxt[0] if nxt and nxt[0] not in keys else ""
                started = txt[0].replace(" ", "") == "예정시간"
                continue
            if not any(txt[:12]):
                continue
            t = t2min(cells[0])
            if t is None:
                continue
            n += 1
            names = split_names(txt[8])
            actual = names if names and all(x in known for x in names) else None
            k = len(names) or int(to_float(txt[10]) or 0)
            jobs.append(Job(date=day, time=t, ship=txt[1], gt=to_float(cells[3]), frm=txt[4], to=txt[5],
                            kind=txt[7].upper(), need_k=k, note=txt[11], actual=actual, seq=n))
        if n:
            names = lambda s: split_names(s, known)
            left = []
            for mm in re.finditer(r"\((\d{1,2}):(\d{2})\)([^()]*)", head.get("조기퇴근", "")):
                left += [(int(mm.group(1)) * 60 + int(mm.group(2)), x) for x in names(mm.group(3))]
            heads[day] = dict(bon=names(head.get("본항당직", "")), onsan=names(head.get("온산당직", "")),
                              cross=names(head.get("교차당직", "")), left=left, repair=names(head.get("수리선", "")))
    wb.close()
    jobs.sort(key=lambda j: (j.stamp, j.seq))
    return jobs, heads


class Dataset:
    """세 엑셀을 한 번에 읽어 둔 묶음"""

    def __init__(self, folder: Path = C.DATA_DIR, need_logs=True):
        """need_logs: True(필수) / False(안 읽음) / 'auto'(있으면 읽음)"""
        folder = Path(folder)
        if need_logs == "auto":
            need_logs = (folder / C.F_LOG).is_file()
        missing = [f for f in (C.F_DUTY, C.F_COUNT) + ((C.F_LOG,) if need_logs else ()) if not (folder / f).is_file()]
        if missing:
            raise FileNotFoundError(f"{folder}에 없음: {', '.join(missing)}  → config.py의 F_DUTY/F_COUNT/F_LOG 확인")
        self.grp, self.plan = load_duty(folder / C.F_DUTY)
        self.history = load_history(folder / C.F_COUNT)
        self.official, self.asof = load_official_counts(folder / C.F_COUNT)
        self.tugs = sorted(t for t in self.grp if t in self.official)        # 후보: 현재 건수 시트에 있는 예선
        self.tier = {t: (self.grp[t] if self.grp[t] < 3000 or t in C.K3 else 4000) for t in self.tugs}
        self.logs, self.heads = (load_logs(folder / C.F_LOG, set(self.grp)) if need_logs else ([], {}))

    def dayinfo(self, d: dt.date) -> dict:
        """그날의 당직 정보: 작업일지 머리글 > 당직표 > 없음"""
        return self.heads.get(d) or self.plan.get(d) or EMPTY_DAY
