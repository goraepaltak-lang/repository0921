# -*- coding: utf-8 -*-
"""설정: 파일 이름, 경로, 모델, 상수를 한 곳에 모은다. (실행 전 여기만 고치면 된다)"""
import datetime as dt
from pathlib import Path

ROOT = Path(__file__).resolve().parent

# ── 원본 엑셀 (data 폴더) ── 실제 파일 이름으로 바꿀 것
DATA_DIR = ROOT / "data"
F_DUTY = "TUG 당직표.xlsx"        # 당직표: 'YYYY년 M월' 시트, 4행부터 날짜별 당직선 (열 위치는 DUTY_COLS)
F_COUNT = "건수일지.xlsx"          # 건수일지: 'YYYY년 작업(n)' 시트 + '★전체 건수★(2026)' 시트
F_LOG = "작업일지.xlsx"            # 작업일지: 'YY년 M월일지(d)' 시트 (머리글에 당직/조기퇴근/수리선)

# ── 다른 스크립트가 만드는 파일 ──
DB = ROOT / "tug_agent.db"                     # Crawling.py / Build_db.py
MANUAL_INDEX = ROOT / "manual.index"           # Build_vectors.py
MANUAL_CHUNKS = ROOT / "manual_chunks.json"
WEIGHTS = ROOT / "weights.json"                # 평가(학습) 때 저장되는 점수 모델 가중치
LLM_CACHE = ROOT / "llm_cache.jsonl"           # 같은 질문을 다시 묻지 않도록 LLM 답 저장
OUT_DIR = ROOT / "결과"

# ── 모델 ──
LLM_MODEL = "qwen3:4b"          # 팀 공통으로 하나만 쓴다 (8b로 바꿔 비교 가능)
EMBED_MODEL = "embeddinggemma"  # Build_vectors.py와 같아야 한다

# ── 배정 파라미터 ──
TOP_M = 4                 # LLM에게 보여줄 자리별 후보 수 (점수 상위 M척)
MAX_GAP = 1.5             # 1위와 점수 차가 이 이내인 후보만 LLM에게 보여준다 (애매한 경우에만 AI 개입)
                          # 모든 자리에서 후보가 1척뿐이면 LLM을 부르지 않는다
CASES_K = 5               # RAG: 함께 보여줄 과거 유사 사례 수
RULE_START = dt.date(2025, 3, 1)   # 톤수표 시행일

# 당직표 열 위치 -> 마력군 (팀원 분석 기준: 1,300 6척 / 1,500 8척 / 2,000 10척 / 3,000 24척)
DUTY_COLS = {3: 1300, 4: 1300, 5: 1500, 6: 1500, 7: 2000, 8: 2000, 9: 3000, 10: 3000, 11: 3000,
             12: 1300, 13: 1300, 14: 1500, 15: 1500, 16: 2000, 17: 2000}
DUTY_ONSAN, DUTY_CROSS, DUTY_BON = range(3, 10), range(10, 11), range(11, 18)   # 온산 / 교차 / 본항 당직 열

# 3,000마력군 중 T/L 순서(4K 이상 16척)에 없는 8척 = 3K급
K3 = {"해7", "처용", "선909", "제우스", "조13", "SBM11", "선11", "흥3"}

# 부두의 항(본항/온산)은 학습 기간 야간 당직 기록으로 추정한다(팀원 방식).
# 기록에 없는 부두는 아래 접두어 규칙으로 보충. False로 하면 팀원 '근거계산' 숫자를 그대로 재현한다.
PORT_PREFIX_FALLBACK = True

# 부두 접두어 -> 항 (기록으로 항을 못 정한 부두에만 쓰는 보조 규칙)
BONHANG_PREFIX = ("P#", "GP", "HCP", "YMP", "YEP", "H#", "HMD")   # 공백 제거 후 비교 ('P #3' -> 'P#3')
