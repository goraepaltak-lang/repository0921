# -*- coding: utf-8 -*-
"""① 규칙 필터 + 후보 특징.

작업 1건마다 전체 예선(48척)의 특징 행렬 X를 만든다. 항목 정의는 팀원 '평가지표_근거계산.py'와 같다.
  - 걸러내기(하드 규칙): 톤수표 최소 마력 미달, 비고의 'N HP 이상' 미달 -> 후보에서 제외
  - 나머지 규칙/경험은 점수 항목(특징)으로 넣고 ②점수 모델이 가중치를 정한다
상태(State)는 '그 시점까지 실제로 일어난 일'(건수, 마지막 작업, 선박 이력)을 들고 다닌다.
"""
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from typing import Optional

import numpy as np

import config as C
from common import Job, allowed_tier, port_by_prefix, requested_tier, slot_of, work_minutes

FEATURES = ["마력급 일치", "상위 마력",
            "당직선(평일 오전)", "당직선(오후·주말 주간)", "당직선(야간)",
            "같은 항(평일 오전)", "같은 항(오후·주말 주간)", "같은 항(야간)",
            "건수 적음(평일 오전)", "건수 적음(그 외)",
            "쉰 시간 김", "작업 중 추정", "조기퇴근함", "수리선",
            "방금 작업을 마침", "같은 부두에서 이어서", "그 배를 맡았던 이력"]
RULE_F = FEATURES[:14]      # 매뉴얼에 근거가 있는 항목
EXP_F = FEATURES[14:]       # 매뉴얼에 없고 기록에 나타나는 항목
F = {f: i for i, f in enumerate(FEATURES)}
BLOCK = ("작업 중 추정", "조기퇴근함", "수리선")   # LLM이 고르면 안 되는 상태


class State:
    """그 시점까지의 실제 상태. apply()로 배정 1건씩 반영한다."""

    def __init__(self, ds, counts: dict, cases=None):
        self.ds = ds
        self.count = Counter(counts)
        self.last = {}                              # 예선 -> (시작, 끝 추정, 부두)
        self.ship_hist = defaultdict(Counter)       # 선박 -> {예선: 횟수}
        self.cases = cases                          # rag.CaseIndex (선택)
        self.peers = {t: [m for m in ds.tugs if ds.tier[m] == ds.tier[t] and m != t] for t in ds.tugs}

    def apply(self, job: Job, names: list, track_ship=True):
        dur = work_minutes(job.gt, "U" if job.kind == "U" else "M")
        for n in names:
            self.count[n] += 1
            if track_ship:
                self.ship_hist[job.ship][n] += 1
            self.last[n] = (job.stamp, job.stamp + dur, job.berth)
        if self.cases is not None:
            self.cases.add(job, names)


@dataclass
class JobCtx:
    job: Job
    slot: str
    need: list                  # 자리별 허용 등급 집합
    X: np.ndarray               # (예선 수, 항목 수)
    tugs: list
    tix: dict
    g: np.ndarray               # 예선별 등급
    port: Optional[str]
    req_tier: Optional[int] = None
    cases: list = field(default_factory=list)   # ③ RAG: 이 시점에 검색한 과거 유사 사례
    ship_top: list = field(default_factory=list)


def learn_berth_port(ds, jobs: list, until) -> dict:
    """학습 기간 야간 작업에서 '어느 쪽 당직선이 맡았나'로 부두의 항을 추정"""
    bp = defaultdict(Counter)
    for j in jobs:
        if j.date > until or not j.actual or j.kind not in ("M", "U") or slot_of(j.date, j.time) != "야간":
            continue
        dd = ds.dayinfo(j.duty_date)
        for n in j.actual:
            for port in ("bon", "onsan"):
                if n in dd[port]:
                    bp[j.berth][port] += 1
    return {b: c.most_common(1)[0][0] for b, c in bp.items()}


def build(job: Job, st: State, berth_port: dict) -> Optional[JobCtx]:
    """작업 1건 -> 후보 특징 행렬. 톤수나 척수를 모르면 None"""
    if job.gt is None or job.need_k <= 0:
        return None
    ds = st.ds
    tugs, tix = ds.tugs, {t: i for i, t in enumerate(ds.tugs)}
    slot = slot_of(job.date, job.time)
    dd = ds.dayinfo(job.duty_date)
    duty = set(dd["bon"]) | set(dd["onsan"]) | set(dd["cross"])
    port = berth_port.get(job.berth) or (port_by_prefix(job.berth) if C.PORT_PREFIX_FALLBACK else None)
    same = (set(dd[port]) | set(dd["cross"])) if port else set()
    gone = {n for t, n in dd["left"] if (job.duty_date < job.date or t <= job.time)} - duty
    repair = set(dd["repair"])
    am, pm, night = slot == "평일 오전", slot in ("평일 오후", "주말 주간"), slot == "야간"
    now = job.stamp
    sh = st.ship_hist[job.ship]
    sh_tot = sum(sh.values())
    X = np.zeros((len(tugs), len(FEATURES)))
    for n, i in tix.items():
        ps = st.peers[n]             # 같은 등급 안에서 건수가 적을수록 1 (처진 예선)
        cnt = (sum(st.count[m] > st.count[n] for m in ps) + 0.5 * sum(st.count[m] == st.count[n] for m in ps)) / max(1, len(ps))
        ls = st.last.get(n)
        since = now - ls[0] if ls else 10 ** 6
        busy = bool(ls) and now < ls[1]
        X[i, 2], X[i, 3], X[i, 4] = (n in duty) * am, (n in duty) * pm, (n in duty) * night
        X[i, 5], X[i, 6], X[i, 7] = (n in same) * am, (n in same) * pm, (n in same) * night
        X[i, 8], X[i, 9] = cnt * am, cnt * (not am)
        X[i, 10] = min(since, 720) / 720
        X[i, 11], X[i, 12], X[i, 13] = busy, n in gone, n in repair
        X[i, 14] = bool(ls) and not busy and now - ls[1] <= 60
        X[i, 15] = bool(ls) and since <= 180 and ls[2] == job.berth and bool(job.berth)
        X[i, 16] = sh[n] / (sh_tot + 5)
    g = np.array([ds.tier[t] for t in tugs])
    return JobCtx(job=job, slot=slot, need=allowed_tier(job.gt, job.need_k), X=X, tugs=tugs, tix=tix, g=g,
                  port=port, req_tier=requested_tier(job.note),
                  ship_top=[n for n, _ in sh.most_common(3)])


def slot_matrix(ctx: JobCtx, s: int, picked: list):
    """자리 s의 (특징, 후보 마스크). 하드 규칙: 최소 마력 미달·이미 뽑힌 예선은 제외"""
    need = ctx.need[s]
    X = ctx.X.copy()
    X[:, 0] = np.isin(ctx.g, list(need))
    X[:, 1] = ctx.g > max(need)
    mask = ctx.g >= min(need)
    if ctx.req_tier:
        mask &= ctx.g >= ctx.req_tier
    for p in picked:
        mask[ctx.tix[p]] = False
    return X, mask


def describe(ctx: JobCtx, name: str) -> str:
    """후보 1척의 상태를 사람이/LLM이 읽을 짧은 문장으로"""
    x = ctx.X[ctx.tix[name]]
    tags = []
    if x[2] or x[3] or x[4]:
        tags.append("당직선")
    if x[5] or x[6] or x[7]:
        tags.append("같은 항")
    lag = x[8] or x[9]
    tags.append(f"건수 처짐 {lag:.0%}")
    tags.append(f"쉰 시간 {x[10] * 12:.1f}h" + ("+" if x[10] >= 1 else ""))
    for f in BLOCK:
        if x[F[f]]:
            tags.append(f"⚠{f}")
    if x[F["같은 부두에서 이어서"]]:
        tags.append("같은 부두 연속")
    if x[F["그 배를 맡았던 이력"]] > 0:
        tags.append(f"이 배 담당 이력 {x[F['그 배를 맡았던 이력']]:.0%}")
    return ", ".join(tags)


def blocked(ctx: JobCtx, name: str) -> list:
    x = ctx.X[ctx.tix[name]]
    return [f for f in BLOCK if x[F[f]]]
