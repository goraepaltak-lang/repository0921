# -*- coding: utf-8 -*-
"""전체 연결: ① 규칙 필터 → ② 점수 모델 → ③ RAG → ④ LLM 선택 → ⑤ 검증·대체

  모드 A/B/C : ②까지만 (점수 1위를 차례로 고름)
  모드 D     : C의 자리별 상위 후보 중에서 LLM이 고름 (RAG 없음)
  모드 E     : D + 과거 사례·매뉴얼 근거(RAG)를 함께 줌  ← 최종 시스템
LLM은 후보 목록 밖의 예선을 고를 수 없고, 규칙을 어기면 그 자리는 점수 1위로 대체된다.
"""
import config as C
from common import Decision
from features import JobCtx, blocked, describe
from rag import ManualRAG, manual_query
from scorer import predict, ranked

SYSTEM = """너는 울산항 예선 배정 보조자다. 규칙과 점수 모델이 자리별 후보를 이미 골라 두었다.
각 자리마다 그 자리의 후보 목록 안에서만 예선 1척을 고른다.
- 기본은 점수 1위다. 1위가 아닌 예선을 고르려면 근거가 분명해야 한다:
  비고(REMARKS)의 요청, 같은 선박·같은 부두의 과거 담당 사례, 매뉴얼 규칙.
- 같은 예선을 두 자리에 쓰지 않는다. ⚠ 표시(작업 중·조기퇴근·수리)가 있는 예선은 고르지 않는다.
- reason에는 1위와 다르게 고른 이유(같으면 '점수 1위 유지')를 60자 이내 한국어로 쓴다. JSON만 출력한다."""


def _case_lines(ctx: JobCtx) -> list:
    out = []
    for j, names, why in ctx.cases:
        out.append(f"- [{why}] {j.date:%m/%d} {j.time // 60:02d}:{j.time % 60:02d} {j.ship} {j.kind} {j.berth} "
                   f"G/T {int(j.gt or 0):,} → {', '.join(names)}")
    if ctx.ship_top:
        out.append(f"- 이 선박을 가장 많이 맡은 예선: {', '.join(ctx.ship_top)}")
    return out


def build_prompt(ctx: JobCtx, slot_cands: list, use_rag: bool, manual: ManualRAG):
    j = ctx.job
    lines = [f"[작업] {j.date:%Y-%m-%d} {j.time // 60:02d}:{j.time % 60:02d} ({ctx.slot}) {j.ship} "
             f"G/T {int(j.gt):,} {dict(M='접안', U='출항', S='이선').get(j.kind, j.kind)} 부두 {j.berth} "
             f"항 {dict(bon='본항', onsan='온산').get(ctx.port, '미상')} 필요 {len(ctx.need)}척",
             f"[비고] {j.note or '없음'}"]
    for s, cands in enumerate(slot_cands, 1):
        need = "/".join(str(x) for x in sorted(ctx.need[s - 1]))
        lines.append(f"[자리{s} 후보] (톤수표 마력급 {need})")
        for r, (n, sc) in enumerate(cands, 1):
            lines.append(f"  {r}. {n} 점수 {sc:+.2f} | {describe(ctx, n)}")
    evidence = {}
    if use_rag:
        cases = _case_lines(ctx)
        if cases:
            lines.append("[과거 유사 사례]")
            lines += cases
        tier = max(ctx.need[0])
        snippets = manual.search(manual_query(ctx.slot, tier, j)) if manual else []
        if snippets:
            lines.append("[매뉴얼]")
            lines += [f"- {s}" for s in snippets]
        evidence = {"cases": cases, "manual": snippets}
    return "\n".join(lines), evidence


def _schema(slot_cands):
    props = {f"slot{s}": {"type": "string", "enum": [n for n, _ in c]} for s, c in enumerate(slot_cands, 1)}
    props["reason"] = {"type": "string"}
    return {"type": "object", "properties": props, "required": list(props), "additionalProperties": False}


def decide(ctx: JobCtx, mode: str, scorers: dict, llm=None, manual: ManualRAG = None) -> Decision:
    if mode in ("A", "B", "C"):
        picked, ranks = predict(ctx, scorers[mode])
        return Decision(picked=picked, mode=mode, ranks=[r[:C.TOP_M] for r in ranks])

    # D / E : C의 자리별 상위 후보 중 '1위와 점수 차가 작은' 후보만 LLM에게 보여준다
    base = scorers["C"]
    base_pick, base_ranks = predict(ctx, base)
    top_ranks = [r[:C.TOP_M] for r in base_ranks]
    slot_cands = [[(n, sc) for n, sc in r[:C.TOP_M] if r[0][1] - sc <= C.MAX_GAP] for r in base_ranks]
    if not all(slot_cands):
        return Decision(picked=base_pick, mode=mode, ranks=top_ranks, status="rule:후보 없음")
    if all(len(c) == 1 for c in slot_cands):
        return Decision(picked=base_pick, mode=mode, ranks=top_ranks, status="rule:점수 차 큼",
                        reason="점수 1위가 뚜렷해 LLM 없이 확정")
    if not llm or not llm.enabled:
        return Decision(picked=base_pick, mode=mode, ranks=top_ranks, status="llm_off", reason="LLM 없음 → C 결과")
    user, evidence = build_prompt(ctx, slot_cands, use_rag=(mode == "E"), manual=manual)
    ans = llm.ask(SYSTEM, user, _schema(slot_cands))
    if not isinstance(ans, dict):
        return Decision(picked=base_pick, mode=mode, ranks=top_ranks, status="llm_fallback:응답 없음",
                        reason="LLM 응답 실패 → C 결과", evidence=evidence)

    # ⑤ 검증: 후보 안 / 중복 없음 / 차단 상태 아님. 어기면 그 자리는 점수 순으로 대체
    picked, problems = [], []
    for s, cands in enumerate(slot_cands, 1):
        names = [n for n, _ in cands]
        want = str(ans.get(f"slot{s}", "")).strip()
        if want not in names:
            problems.append(f"자리{s} 후보 밖")
        elif want in picked:
            problems.append(f"자리{s} 중복")
        elif blocked(ctx, want) and not blocked(ctx, names[0]):
            problems.append(f"자리{s} {blocked(ctx, want)[0]}")
        else:
            picked.append(want)
            continue
        alt = next((n for n, _ in ranked(ctx, base, s - 1, picked)), None)
        if alt:
            picked.append(alt)
    status = "llm_ok" if not problems else "llm_fallback:" + ",".join(problems)
    return Decision(picked=picked, mode=mode, ranks=top_ranks, status=status,
                    reason=str(ans.get("reason", ""))[:120], evidence=evidence)
