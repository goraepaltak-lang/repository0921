# -*- coding: utf-8 -*-
"""④ LLM 호출 (Ollama). 같은 질문은 llm_cache.jsonl에서 꺼내 다시 묻지 않는다.

client를 바꿔 끼울 수 있어서(테스트용 가짜 LLM 등) 다른 팀원이 모델을 바꿔도 이 파일만 고치면 된다.
"""
import hashlib
import json
import sys
import time

import config as C


class LLM:
    def __init__(self, model: str = C.LLM_MODEL, cache_path=C.LLM_CACHE, client=None):
        self.model = model
        self.cache_path = cache_path
        self.cache = {}
        self.calls = self.hits = self.errors = 0
        self.seconds = 0.0
        if client is None:
            try:
                import ollama
                client = ollama
            except ImportError:
                client = None
        self.client = client
        self.enabled = client is not None
        if cache_path and cache_path.exists():
            for line in cache_path.read_text(encoding="utf-8").splitlines():
                try:
                    d = json.loads(line)
                    self.cache[d["key"]] = d["answer"]
                except (ValueError, KeyError):
                    continue

    def ask(self, system: str, user: str, schema: dict):
        """JSON 답(dict) 또는 None(실패). 스키마로 출력 형식을 강제한다."""
        if not self.enabled:
            return None
        key = hashlib.sha1(f"{self.model}\n{system}\n{user}".encode("utf-8")).hexdigest()
        if key in self.cache:
            self.hits += 1
            return self.cache[key]
        t0 = time.time()
        try:
            r = self.client.chat(model=self.model, think=False, format=schema,
                                 options={"temperature": 0, "num_ctx": 4096, "num_predict": 300},
                                 messages=[{"role": "system", "content": system},
                                           {"role": "user", "content": user}])
            content = r["message"]["content"] if isinstance(r, dict) else r.message.content
            answer = json.loads(content or "{}")
        except Exception as e:
            self.errors += 1
            if self.errors <= 3:
                print(f"[LLM 오류] {type(e).__name__}: {e}", file=sys.stderr)
            if self.errors >= 5 and self.calls == 0:
                print("[LLM 끔] 연속 실패 → 점수 모델 결과만 사용", file=sys.stderr)
                self.enabled = False
            return None
        finally:
            self.seconds += time.time() - t0
        self.calls += 1
        self.cache[key] = answer
        if self.cache_path:
            with open(self.cache_path, "a", encoding="utf-8") as f:
                f.write(json.dumps({"key": key, "answer": answer}, ensure_ascii=False) + "\n")
        return answer
