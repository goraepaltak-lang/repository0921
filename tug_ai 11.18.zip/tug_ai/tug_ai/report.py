# -*- coding: utf-8 -*-
"""엑셀 보고서 쓰기 (모든 결과 파일이 같은 모양이 되도록 한 곳에서)"""
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill


def write_xlsx(path: Path, sheets: dict):
    """sheets: {시트명: [머리글, 행, 행, ...]}"""
    wb = Workbook()
    wb.remove(wb.active)
    for name, rows in sheets.items():
        ws = wb.create_sheet(name[:31])
        for r in rows:
            ws.append(list(r))
        if not rows:
            continue
        for c in ws[1]:
            c.fill = PatternFill("solid", fgColor="17324F")
            c.font = Font(color="FFFFFF", bold=True)
        ws.freeze_panes = "A2"
        for col in ws.columns:
            width = max(len(str(c.value or "")) for c in col)
            ws.column_dimensions[col[0].column_letter].width = min(60, max(8, width * 1.3))
            for c in col:
                c.alignment = Alignment(vertical="center", wrap_text=True)
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(path)
    return path
