# TUG AI 배정 시스템

규칙이 기본 틀을 정하고, 학습한 점수 모델이 후보를 좁히고, **애매한 경우에만 LLM이 RAG 근거를 보고 고르는** 예선 배정 시스템.
최종 배정은 담당자가 확인한다 (검토용).

```
오늘 작업 (Crawling → forecast DB)
 → ① 규칙 필터    features.py   톤수표 최소 마력, 비고의 'N HP 이상' 미달 제외 + 후보 특징 17개
 → ② 점수 모델    scorer.py     A 규칙 그대로 / B 규칙+가중치 / C 규칙+경험 (조건부 로짓, 과거 기록으로 학습)
 → ③ RAG         rag.py        과거 배정 사례(같은 선박·같은 부두, RRF 결합) + 매뉴얼 조항(FAISS)
 → ④ LLM 선택     llm.py        1위와 점수 차가 MAX_GAP 이내인 후보 중에서만 고름 (JSON 스키마로 후보 이름만 허용)
 → ⑤ 검증·대체    pipeline.py   후보 밖·중복·작업 중/조기퇴근/수리 → 그 자리는 점수 순으로 대체
 → 배정안 + 근거   today.py      결과/오늘배정_날짜.xlsx
```

AI가 하는 일: ② 가중치를 과거 기록에서 학습 + ③④ 점수로 결정이 애매한 경우에 근거를 찾아 최종 선택.
AI가 못 하는 일: 후보 밖 예선 선택, 톤수표 위반, 작업 중인 예선 배정 (⑤에서 막음).

## 실행

```bash
pip install openpyxl numpy ollama pydantic faiss-cpu pandas playwright lxml
ollama pull qwen3:4b && ollama pull embeddinggemma

# 0) 설정: config.py의 F_DUTY / F_COUNT / F_LOG를 data 폴더의 실제 엑셀 이름으로
# 1) 매뉴얼 인덱스 (매뉴얼 바뀔 때만)
python Build_vectors.py
# 2) 평가 + 가중치 학습 (공식 점수판) -> 결과/평가결과_*.xlsx, weights.json
python evaluate.py --train-until 2026-07-20 --llm-limit 150
# 3) 오늘 배정안 (도선예보 없으면 크롤링부터)
python today.py --mode E
# 또는 메뉴
python main.py
```

실제 데이터·Ollama 없이 동작 점검: `python tests/smoke_test.py` (가짜 데이터 + 가짜 LLM)

## 파일과 담당

| 파일 | 하는 일 | 담당 (팀에서 정하기) | 출처 |
|---|---|---|---|
| Crawling.py, Build_db.py | 도선예보 수집, DB 저장 | 데이터 | 기존 |
| config.py | 파일 이름·모델·상수 (모두 여기서만 고침) | 공통 | 신규 |
| common.py | **공통 형식 Job / Decision**, 톤수표, 시간대, 이름 통일 | 공통 | 근거계산 + Tug_Agent |
| data.py | 당직표·건수일지·작업일지 읽기 | 데이터 | 근거계산 로더 일반화 |
| features.py | ① 규칙 필터 + 후보 특징, 상태(State) | 점수 모델 | 근거계산 |
| scorer.py | ② A/B/C 점수, 가중치 학습 | 점수 모델 | 근거계산 |
| rag.py | ③ 과거 사례 검색 + 매뉴얼 검색 | RAG·LLM | agent_v9 + 신규 |
| llm.py, pipeline.py | ④ LLM 선택, ⑤ 검증·대체 | RAG·LLM | agent_v9 방식 + 신규 |
| evaluate.py, report.py | 공식 점수판 (A~E 비교, 엑셀 보고서) | 평가 | 근거계산 + v13 |
| today.py, main.py | 오늘 배정, 통합 메뉴 | 평가/통합 | Tug_Agent + v14 |
| Build_vectors.py, agent_v9_fixed.py | 매뉴얼 인덱스, YES/NO 질의 | RAG·LLM | 기존 |

## 팀 규칙 (결과물이 갈라지지 않게)

1. **단계 사이에는 `common.Job`, `features.JobCtx`, `common.Decision`만 주고받는다.** 형식을 바꿀 땐 팀에 먼저 알린다.
2. **성능 주장은 `evaluate.py` 숫자로만 한다.** 고친 뒤 같은 `--train-until`로 다시 돌려 `결과/평가결과_*.xlsx`를 공유한다.
3. 새 점수 항목 추가: `features.FEATURES`에 이름 추가 → `build()`에서 값 계산 → (경험 항목이면 `EXP_F`) → evaluate로 B/C 재학습.
4. 상수·파일 이름은 `config.py`에서만 바꾼다.

## 평가 보고서 읽는 법

- **요약**: 방식별 건 완전 일치율 / 예선 일치율 / 상위 후보(척수+2) 포함률. LLM 비교 구간은 같은 작업으로 A~E를 비교한 값.
- **LLM 효과**: LLM이 C의 선택을 바꾼 건수, 바꿔서 맞힌 예선 − 틀린 예선 (AI 개입의 순효과), 대체(fallback) 횟수.
- **시간대별**: 평일 오전 / 평일 오후 / 주말 주간 / 야간별 예선 일치율.
- **건별 비교**: 실제 배정 vs A~E, E의 이유와 근거 사례 → 불일치 사례를 담당자 인터뷰에 쓴다.
- **톤수표 검증**: 톤수표대로 정한 마력군과 실제의 일치율.

D와 E의 차이 = RAG(과거 사례·매뉴얼)의 효과, C와 E의 차이 = AI 개입 전체의 효과.

## 한계 / 할 일

- 평가 기간은 당직 머리글이 있는 작업일지가 있는 달뿐 (현재 7월). 달이 늘수록 신뢰도가 오른다.
- 건수 시작값은 공식 건수에서 기간 작업 수를 빼서 만든다 (보존건수·페널티 미반영).
- 오늘 배정: 오늘 이미 끝난 작업의 사용 예선을 모름 → 작업 중·건수 판단이 실제와 다를 수 있음.
- 미반영: T/L·LNG·HHI/HMD 특수작업, 건수조정기간, 0순번, 당직표 비고란 수리 판정(v12 `repair_mentions`), 척수 결정.
- `PORT_PREFIX_FALLBACK = False`로 하면 팀원 '평가지표_근거계산'과 같은 방식으로 항을 정한다. 같은 `--train-until`로 돌려 숫자가 거의 같게 나오는지 보면 통합이 맞게 됐는지 확인할 수 있다(시간 칸이 빈 행 처리 등 사소한 차이는 있을 수 있음).
