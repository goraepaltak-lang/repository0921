# -*- coding: utf-8 -*-
"""② 점수 모델: 후보 예선에 점수를 매겨 순위를 낸다.

  A. 규칙 그대로   : 매뉴얼의 시간대별 순서를 사전식 점수로 옮김 (학습 없음)
  B. 규칙 + 가중치 : 규칙 항목만, 가중치를 과거 기록에 맞춤 (조건부 로짓)
  C. 규칙 + 경험   : 규칙 + 경험 항목, 가중치를 과거 기록에 맞춤
"""
import json
from pathlib import Path

import numpy as np

from features import EXP_F, FEATURES, RULE_F, JobCtx, slot_matrix


def score_rule_as_written(ctx: JobCtx, X):
    """A: 평일 오전은 처진순, 그 외는 당직선 -> 같은 항 -> 오래 쉰 예선"""
    base = 1e6 * X[:, 0] - 1e7 * (X[:, 12] + X[:, 13]) - 1e5 * X[:, 11]
    if ctx.slot == "평일 오전":
        return base + 1e3 * X[:, 8] + X[:, 10]
    duty = X[:, 3] + X[:, 4]
    same = X[:, 6] + X[:, 7]
    return base + 1e4 * duty + 1e3 * same + 10 * X[:, 10]


class Model:
    """가중치 {항목: 값}을 가진 선형 점수 모델 (B/C)"""

    def __init__(self, weights: dict, name="C"):
        self.name = name
        self.w = {f: float(weights.get(f, 0.0)) for f in FEATURES}
        self.vec = np.array([self.w[f] for f in FEATURES])

    def __call__(self, ctx, X):
        return X @ self.vec

    def save(self, path: Path, meta=None):
        Path(path).write_text(json.dumps({"model": self.name, "weights": self.w, "meta": meta or {}},
                                         ensure_ascii=False, indent=2), encoding="utf-8")

    @classmethod
    def load(cls, path: Path):
        d = json.loads(Path(path).read_text(encoding="utf-8"))
        return cls(d["weights"], d.get("model", "C"))


def fit(ctxs: list, features: list, l2=1.0, iters=600, lr=0.5, name="C") -> Model:
    """조건부 로짓: 후보 중 실제로 뽑힌 예선의 점수가 가장 높아지도록 가중치를 맞춘다."""
    cols = [FEATURES.index(f) for f in features]
    Xs, Ms, Ys = [], [], []
    for ctx in ctxs:
        picked = []
        for s, a in enumerate(ctx.job.actual):
            X, mask = slot_matrix(ctx, s, picked)
            if mask[ctx.tix[a]]:
                Xs.append(X[:, cols]); Ms.append(mask); Ys.append(ctx.tix[a])
            picked.append(a)
    if not Ys:
        raise ValueError("학습할 작업이 없습니다.")
    X, M, Y = np.array(Xs), np.array(Ms), np.array(Ys)
    w = np.zeros(len(cols))
    idx = np.arange(len(Y))
    for _ in range(iters):
        z = np.where(M, X @ w, -1e9)
        z -= z.max(axis=1, keepdims=True)
        p = np.exp(z); p /= p.sum(axis=1, keepdims=True)
        grad = (X[idx, Y] - (p[:, :, None] * X).sum(axis=1)).mean(axis=0) - l2 * w / len(Y)
        w += lr * grad
    return Model(dict(zip(features, w)), name)


def ranked(ctx: JobCtx, scorer, s: int, picked: list) -> list:
    """자리 s의 후보 순위 [(예선, 점수), ...] (걸러진 예선은 빠짐)"""
    X, mask = slot_matrix(ctx, s, picked)
    sc = scorer(ctx, X)
    order = np.argsort(-np.where(mask, sc, -np.inf), kind="stable")
    return [(ctx.tugs[i], float(sc[i])) for i in order if mask[i]]


def predict(ctx: JobCtx, scorer):
    """자리 순서대로 1위를 뽑는다 -> (배정, 자리별 순위)"""
    picked, ranks = [], []
    for s in range(len(ctx.need)):
        r = ranked(ctx, scorer, s, picked)
        ranks.append(r)
        if r:
            picked.append(r[0][0])
    return picked, ranks


MODELS_B_FEATURES, MODELS_C_FEATURES = RULE_F, RULE_F + EXP_F
