# -*- coding: utf-8 -*-
"""공통 형식(Job, Decision)과 공통 도구. 모든 단계는 이 형식으로만 주고받는다."""
import datetime as dt
import re
from dataclasses import dataclass, field
from typing import Optional

import config as C

SPLIT = r"[,/\s.+]+"
ANCHORAGE = re.compile(r"\bE-\d\b")


# ───────────────────────────── 공통 형식
@dataclass
class Job:
    """작업 1건. 작업일지(과거)와 도선예보(오늘) 모두 이 형식으로 바꾼다."""
    date: dt.date
    time: int                    # 0~1439 (분)
    ship: str
    gt: Optional[float]
    frm: str
    to: str
    kind: str                    # M(접안) / U(출항) / S(이선)
    need_k: int                  # 필요 척수
    note: str = ""               # 비고 / REMARKS
    actual: Optional[list] = None   # 실제 사용 예선 (과거 기록일 때만)
    seq: int = 0

    @property
    def berth(self) -> str:
        if self.kind == "U":
            return self.frm
        if self.kind == "S" and ANCHORAGE.search(self.to):
            return self.frm
        return self.to

    @property
    def stamp(self) -> int:
        """날짜를 넘나드는 비교용 누적 분"""
        return self.date.toordinal() * 1440 + self.time

    @property
    def duty_date(self) -> dt.date:
        """06:00 전 작업은 전날 당직이 맡는다"""
        return self.date - dt.timedelta(days=1) if self.time < 360 else self.date

    def label(self) -> str:
        return f"{self.date:%m/%d} {self.time // 60:02d}:{self.time % 60:02d} {self.ship} ({self.kind}, {self.berth})"


@dataclass
class Decision:
    """한 작업에 대한 최종 결정"""
    picked: list                          # 배정 예선 (자리 순서)
    mode: str                             # A/B/C/D/E
    ranks: list = field(default_factory=list)        # 자리별 [(예선, 점수), ...] 상위 후보
    reason: str = ""                      # LLM 또는 규칙의 설명
    status: str = "rule"                  # rule / llm_ok / llm_fallback:<사유> / llm_off
    evidence: dict = field(default_factory=dict)      # 사용한 근거 (매뉴얼, 과거 사례)


# ───────────────────────────── 이름 / 시간
def norm(name) -> str:
    """예선 이름 표기를 하나로 맞춘다 (해강9=해9, 선진6=선6, 109청룡=109)"""
    s = str(name).strip().upper().replace(" ", "")
    for a, b in (("해강", "해"), ("조광", "조"), ("선진", "선"), ("흥진", "흥"), ("청룡", "")):
        s = s.replace(a, b)
    return {"SBM111": "SBM11"}.get(s, s)


def split_names(text, known=None) -> list:
    ns = [norm(x) for x in re.split(SPLIT, str(text or "")) if x.strip()]
    return [n for n in ns if known is None or n in known]


def t2min(v) -> Optional[int]:
    if isinstance(v, (dt.time, dt.datetime)):
        return v.hour * 60 + v.minute
    m = re.match(r"\s*(\d{1,2}):(\d{2})", str(v or ""))
    return int(m.group(1)) * 60 + int(m.group(2)) if m else None


def to_float(v) -> Optional[float]:
    try:
        return float(str(v).replace(",", ""))
    except (TypeError, ValueError):
        return None


def slot_of(day: dt.date, t: int) -> str:
    """매뉴얼 Ⅲ-2 시간대: 평일 오전 / 평일 오후 / 주말 주간 / 야간"""
    weekend = day.weekday() >= 5
    if t < 360 or t >= (930 if weekend else 1050):
        return "야간"
    return "주말 주간" if weekend else ("평일 오전" if t < 720 else "평일 오후")


# ───────────────────────────── 톤수표 (매뉴얼, 2025-03-01 시행)
def allowed(gt: float, k: int) -> list:
    """총톤수와 척수 -> 자리별 허용 마력군 (1300/1500/2000/3000)"""
    if gt < 5000:
        return [{1300, 1500}] * k
    if gt < 7000:
        return [{1500}] + [{1300, 1500}] * (k - 1)
    if gt < 10000:
        return [{1500}] * k
    if gt < 25000:
        return [{2000}] * k
    if gt < 30000:
        return [{3000}] + [{2000}] * (k - 1)
    return [{3000}] * k


def allowed_tier(gt: float, k: int) -> list:
    """3,000마력군을 3K급(3000)과 4K 이상(4000)으로 나눠 읽은 톤수표"""
    if gt < 25000:
        return allowed(gt, k)
    if gt < 30000:
        return [{3000}] + [{2000}] * (k - 1)
    if gt < 50000:
        return [{3000, 4000}] * k
    return [{4000}] * k


def work_minutes(gt: Optional[float], kind: str) -> int:
    """작업 예상 시간표(매뉴얼 Ⅲ-6)의 하한(분). 이선은 1시간 30분."""
    gt = gt or 0
    if kind == "S":
        return 90
    if kind == "U":
        return 15 if gt < 10000 else 30 if gt < 30000 else 60
    return 60 if gt < 30000 else 90 if gt < 50000 else 120


HP_REQ = re.compile(r"(\d[\d,]{2,5})\s*(?:HP|마력)\s*이상", re.I)


def requested_tier(text: str) -> Optional[int]:
    """비고/REMARKS의 'N HP 이상' -> 최소 등급 (정규식, LLM 아님)  [가정] 등급 경계"""
    m = HP_REQ.search(str(text or ""))
    if not m:
        return None
    hp = int(m.group(1).replace(",", ""))
    return 1300 if hp <= 1300 else 1500 if hp <= 1500 else 2000 if hp <= 2000 else 3000 if hp < 4000 else 4000


def port_by_prefix(berth: str) -> Optional[str]:
    b = re.sub(r"\s+", "", berth or "").upper()
    if not b:
        return None
    return "bon" if b.startswith(C.BONHANG_PREFIX) else "onsan"
