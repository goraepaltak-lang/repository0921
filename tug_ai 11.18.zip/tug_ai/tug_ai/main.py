# -*- coding: utf-8 -*-
"""TUG AI 배정 시스템 — 통합 메뉴 (교육·검토용, 최종 배정은 담당자가 확인)"""
import subprocess
import sys

import config as C


def ask(prompt, default=""):
    v = input(f"{prompt}" + (f" [{default}]" if default else "") + ": ").strip()
    return v or default


def main():
    print("TUG AI 배정 시스템 (규칙 + 점수 모델 + RAG + LLM)")
    while True:
        print("\n1. 오늘 배정안 만들기 (도선예보 → 배정 + 근거)")
        print("2. 평가: 과거 작업일지로 A~E 비교 + 가중치 학습")
        print("3. 매뉴얼/당직표 YES·NO 질문 (agent_v9)")
        print("0. 종료")
        try:
            c = input("선택: ").strip()
            if c == "1":
                import today
                today.main(["--date", ask("날짜 YYYY-MM-DD", __import__("datetime").date.today().isoformat()),
                            "--mode", ask("방식 A/C/E", "E")])
            elif c == "2":
                import evaluate
                args = ["--llm-limit", ask("LLM으로 돌릴 작업 수 (0=전부)", "150")]
                if ask("LLM 사용? y/n", "y").lower() != "y":
                    args.append("--no-llm")
                evaluate.main(args)
            elif c == "3":
                script = C.ROOT / "agent_v9_fixed.py"
                if script.is_file():
                    subprocess.run([sys.executable, str(script)], cwd=C.ROOT, check=False)
                else:
                    print("agent_v9_fixed.py가 없습니다.")
            elif c in ("0", "q", "Q"):
                break
        except (KeyboardInterrupt, EOFError):
            print()
            break
        except (FileNotFoundError, LookupError, ValueError) as e:
            print(f"[오류] {e}")
        except SystemExit as e:
            if e.code not in (0, None):
                print(e.code)


if __name__ == "__main__":
    main()
